type ToArray<Type> = Type extends any ? Type[] : never;
